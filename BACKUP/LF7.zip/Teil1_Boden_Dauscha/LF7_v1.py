import RPi.GPIO as GPIO
import dht11
import board
import time
import os
import sys

from adafruit_ht16k33.segments import Seg7x4

# initialize GPIO
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
GPIO.cleanup()
#aufbau einer while schleife zum wiederholten Messdurchfuehrung
i=1
while i < 21:
	#Sensor angeben und mittels der DHT11 Bibliothek auslesen
	instance = dht11.DHT11(pin=4)
	#instance auslesen
	Ergebnis = instance.read()
	# Temperatur Ausgeben auf eine Nachkommastelle genau
	print('Temp: %.1f C*' % Ergebnis.temperature)
	# Luftfeuchtigkeit auf ganze Zahlen genau ausgeben
	print("Feuchtigkeit: %.0f %%" % Ergebnis.humidity)
	#15 sekunden abwarten
	time.sleep(15.0)
    #Schleife nach oben zählen
    i += 1
